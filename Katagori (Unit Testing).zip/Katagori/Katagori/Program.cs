﻿using System;
using System.Diagnostics;

namespace TokoApp
{

    //=========Table driven==================
    public enum Kategori
    {
        AlatTulis = 1,
        AlatGambar = 2,
        SeragamKampus = 3
    }

    public enum AlatTulis
    {
        Pulpen = 1,
        Buku = 2,
        Pensil = 3
    }

    public enum AlatGambar
    {
        PensilWarna = 1,
        Kuas = 2,
        CatAir = 3
    }

    public enum SeragamKampus
    {
        Seragamputih = 1,
        seragammerah = 2,
        Almameter = 3
    }

    public class Program
    {
        public static int pulpenHarga = 3000;
        public static int bukuHarga = 5000;
        public static int pensilHarga = 2000;

        public static int pensilWarnaHarga = 10000;
        public static int kuasHarga = 15000;
        public static int catAirHarga = 20000;

        public static int kaosHarga = 50000;
        public static int kemejaHarga = 75000;
        public static int jaketHarga = 100000;

        public static int totalHarga = 0;
        public static int jumlahItem = 0;


        // ============parameter/generic================
        public static void BeliBarang<T>(string[] daftarBarang, int[] hargaBarang) where T : struct, Enum
        {
            Console.WriteLine($"Barang tersedia ({typeof(T)}):");
            for (int i = 0; i < daftarBarang.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {daftarBarang[i]} harga Rp{hargaBarang[i]}");
            }
          

            Console.Write("Mau beli apa : ");
            //==============desain By Contact==============
            try
            {
                int barangPilihan = int.Parse(Console.ReadLine() ?? "0");
                Debug.Assert(barangPilihan >= 1 && barangPilihan <= daftarBarang.Length, "Input barangPilihan tidak valid");
                Console.Write("Berapa banyak : ");
                int barangJumlah = int.Parse(Console.ReadLine() ?? "0");

                totalHarga += hargaBarang[barangPilihan - 1] * barangJumlah;
                jumlahItem += barangJumlah;
            }
            catch (Exception e)
            {
                Console.WriteLine($"Terjadi kesalahan : {e.Message}");
            }
        }

        public static void BeliAlatTulis()
        {
            string[] daftarAlatTulis = { "Pulpen", "Buku", "Pensil" };
            int[] hargaAlatTulis = { 3000, 5000, 2000 };

            BeliBarang<AlatTulis>(daftarAlatTulis, hargaAlatTulis);
        }

        public static void BeliAlatGambar()
        {
            string[] daftarAlatGambar = { "Pensil warna", "Kuas", "Cat air" };
            int[] hargaAlatGambar = { 10000, 15000, 20000 };

            BeliBarang<AlatGambar>(daftarAlatGambar, hargaAlatGambar);
        }

        public static void BeliSeragamKampus()
        {
            string[] daftarSeramKampus = { "Seragam putih", "Seragam merah", "Almameter telu" };
            int[] hargaSeragamKampus = { 50000, 75000, 100000 };

            BeliBarang<SeragamKampus>(daftarSeramKampus, hargaSeragamKampus);
        }

        public static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Kategori tersedia :");
                Console.WriteLine("1. Alat Tulis");
                Console.WriteLine("2. Alat Gambar");
                Console.WriteLine("3. Seragam Kampus");

                Console.Write("Pilih kategori : ");

                // desain by contact

                try
                {
                    int kategoriPilihan = int.Parse(Console.ReadLine() ?? "0");
                    Debug.Assert(kategoriPilihan >= 1 && kategoriPilihan <= 3, "Input kategoriPilihan tidak valid");
                    Kategori kategori = (Kategori)kategoriPilihan;

                    switch (kategori)
                    {
                        case Kategori.AlatTulis:
                            BeliAlatTulis();
                            break;
                        case Kategori.AlatGambar:
                            BeliAlatGambar();
                            break;
                        case Kategori.SeragamKampus:
                            BeliSeragamKampus();
                            break;
                        default:
                            Console.WriteLine("Kategori tidak valid");
                            break;
                    }
                    Console.WriteLine($"Total harga : Rp{totalHarga}");
                    Console.WriteLine($"Jumlah item : {jumlahItem}");
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Terjadi kesalahan : {e.Message}");
                }

                Console.Write("Mau beli lagi? (y/n) : ");
                string ?jawaban = Console.ReadLine();

                if (jawaban != null && jawaban.ToLower() != "y")
                {
                    Console.WriteLine("Terima kasih telah berbelanja di toko kami!");
                    break;
                }
            }

            Console.ReadKey();
        }
    }
}
    
