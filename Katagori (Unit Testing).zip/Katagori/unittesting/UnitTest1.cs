using TokoApp;
namespace TestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestBelibarang()
        {
            // Arrange
            string[] daftarBarang = { "Pulpen", "Buku", "Pensil" };
            int[] hargaBarang = { 3000, 5000, 2000 };
            int expectedTotalHarga = 10000 * hargaBarang[0];
            int expectedJumlahItem = 10;

            // Act
            Program.totalHarga = 0;
            Program.jumlahItem = 0;
            Program.BeliBarang<AlatTulis>(daftarBarang, hargaBarang);
            int actualTotalHarga = Program.totalHarga;
            int actualJumlahItem = Program.jumlahItem;

            // Assert
            Assert.AreEqual(expectedTotalHarga, actualTotalHarga);
            Assert.AreEqual(expectedJumlahItem, actualJumlahItem);
        }

        
    }
}