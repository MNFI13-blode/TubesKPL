using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TubesKPL;

namespace Pengujian
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void TesverifikasiOTP()
        {
            metodepembayaran newOBJ = new metodepembayaran();

            string hasil3 = newOBJ.pembayaranOTP("123");
            Assert.AreEqual(hasil3, "lanjutkan pembayaran");

            string hasil = newOBJ.pembayaranOTP("12");
            Assert.AreEqual(hasil, " ");


        }

        [TestMethod]
        public void TesqrOTP()
        {
            metodepembayaran newOBJ = new metodepembayaran();
            string hasil1 = newOBJ.qrOTP("123");
            Assert.AreEqual(hasil1, "ctrl + klik pada Link untuk mendapatkan kode QR: https://drive.google.com/file/d/1H4Yfvc_75mjGq_-z0Rf4kHVeCTZP4XnB/view");

            string hasil2 = newOBJ.qrOTP("12");
            Assert.AreEqual(hasil2, "kode tidak valid");
        }
    }
}